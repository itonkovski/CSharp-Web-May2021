﻿using System;

namespace SUS.MvcFramework.Tests
{
    public class TestViewModel
    {
        public string Name { get; set; }

        public decimal Price { get; set; }

        public DateTime DateOfBirth { get; set; }
    }
}
